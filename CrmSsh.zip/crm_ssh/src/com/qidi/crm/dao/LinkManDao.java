package com.qidi.crm.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import com.qidi.crm.bean.LinkMan;

public interface LinkManDao {

	public void save(LinkMan linkMan);
	
	public Integer findCount(DetachedCriteria detachedCriteria);
	
	public List<LinkMan> findByPage(DetachedCriteria detachedCriteria, Integer begin, Integer pageSize);
	
	public LinkMan findById(Long lkm_id);
	
	public void update(LinkMan linkMan);
	
	public void delete(LinkMan linkMan);
}
