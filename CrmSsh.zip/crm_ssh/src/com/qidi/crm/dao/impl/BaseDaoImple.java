package com.qidi.crm.dao.impl;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import com.qidi.crm.dao.BaseDao;

public class BaseDaoImple<T> extends HibernateDaoSupport implements BaseDao<T>{

	@Override
	public void save(T t) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().update(t);
	}

	@Override
	public void update(T t) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().update(t);
	}

	@Override
	public void delete(T t) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().delete(t);
	}
	

}
